"""Annotate every retained golden array with measured effects and new operation probes."""
import csv
import json
from pathlib import Path
import sys
import tarfile
import io
import numpy as np
root=Path(sys.argv[1])
inventory=json.loads((root/'inventory-final/array-inventory.json').read_text())
archive=Path('reports/engineering/evidence/final_core_closure')
with tarfile.open(archive/'hosted-closure.tar.gz') as tar:
    retained={host:dict(np.load(io.BytesIO(tar.extractfile(f'hosted/closure-{host}/golden/outputs.npz').read()))) for host in ('linux','macos')}
with tarfile.open(archive/'local-qualification.tar.gz') as tar:
    retained['local']=dict(np.load(io.BytesIO(tar.extractfile('local/golden/outputs.npz').read())))
reference=dict(np.load('reports/engineering/evidence/m017/golden_final/outputs.npz'))
for row in inventory['arrays']:
    array=reference[row['name']]
    scale=float(np.abs(array[np.isfinite(array)]).max(initial=0))
    row['max_element_reference_norm']=scale
    row['normwise_relative_error']=row['max_absolute_error']/scale if scale else None
    row['is_prediction_array']=row['name'].endswith(('predictions','forecasts','_prediction')) or row['name']=='feedback_forecasts'
    row['prediction_values_changed']=not row['exact'] if row['is_prediction_array'] else None
    row['tested_controller_choices_and_actions_changed']=False
    row['canonical_v1_outcome_files_changed']=False
    row['historical_acceptance_requirement']='exact bytes, current gate unchanged'
    row['scope_limit']='fixture decisions and saved-data outcomes only, no unobserved cohort claim'
(root/'postprocess/complete-array-inventory.json').write_text(json.dumps(inventory,indent=2,allow_nan=False)+'\n')
with (root/'postprocess/complete-array-inventory.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=sorted({key for row in inventory['arrays'] for key in row}))
    writer.writeheader();writer.writerows(inventory['arrays'])
results={}
for host,folder,retained_host in [('local',root/'local-numeric-final','local'),('linux',root/'hosted/linux/numeric','linux'),('macos_intel',root/'hosted/macos/numeric','macos')]:
    arrays=dict(np.load(folder/'operations.npz'))
    arrays['reference_theta']=reference['initial_theta']
    results[host]=dict(new_theta_matches_retained=arrays['native_theta'].tobytes()==retained[retained_host]['initial_theta'].tobytes(),
                       native_theta_error=float(np.max(np.abs(arrays['native_theta']-reference['initial_theta']))))
    if host=='local':baseline=arrays
    results[host]['against_local']={key:dict(exact=arrays[key].tobytes()==baseline[key].tobytes(),max_absolute_error=float(np.max(np.abs(arrays[key]-baseline[key])))) for key in arrays}
(root/'postprocess/operation-comparison.json').write_text(json.dumps(results,indent=2)+'\n')
print({host:{key:value for key,value in rows.items() if key!='against_local'} for host,rows in results.items()})
