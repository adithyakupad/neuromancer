from setuptools import Extension, setup
from Cython.Build import cythonize
from Cython.Compiler import Options
Options.warning_errors = True
setup(name='neuromancer-m029-verification', ext_modules=cythonize([
    Extension('m029_arithmetic', ['/home/runner/work/neuromancer/neuromancer/runs/ordered-build/m029_arithmetic.pyx'], extra_compile_args=['-O3', '-fno-fast-math', '-ffp-contract=off', '-frounding-math'])
]))
