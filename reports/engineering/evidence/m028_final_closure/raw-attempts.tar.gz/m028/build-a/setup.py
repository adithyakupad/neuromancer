from setuptools import setup,Extension
from Cython.Build import cythonize
setup(name="neuromancer-verification-kernels",ext_modules=cythonize([
    Extension("m028_arithmetic",['/Users/adithyaupad/Developer/neuromancer/tools/m028_arithmetic.pyx'],extra_compile_args=["-O3","-fno-fast-math","-ffp-contract=off","-frounding-math"])
],build_dir='/private/tmp/neuromancer-m028/build-a/generated',compiler_directives={"language_level":3,"boundscheck":False,"wraparound":False,"cdivision":True}))
