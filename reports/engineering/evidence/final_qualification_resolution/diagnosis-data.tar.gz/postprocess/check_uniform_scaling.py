"""Explain recorded uniform weights using independently rounded affine arithmetic."""
from decimal import Decimal, localcontext
import json
from pathlib import Path
import numpy as np
from neuromancer._brian import realization, stream, E_COUNT
from neuromancer.substrate import Config
root=Path('/tmp/neuromancer-final-resolution')
config=Config()
parameters=realization(config)
exc=parameters['pre'] < E_COUNT
rng=stream(config,2)
r=rng.random(len(exc))
lower=np.where(exc,12.,-72.)
width=np.where(exc,6.,24.)
plain=np.asarray([float(a)+float(w)*float(x) for a,w,x in zip(lower,width,r,strict=True)])
with localcontext() as context:
 context.prec=100
 fused=np.asarray([float(Decimal(float(a))+Decimal(float(w))*Decimal(float(x))) for a,w,x in zip(lower,width,r,strict=True)])
result={}
for host,folder in [('local',root/'local-numeric-final'),('linux',root/'hosted/linux/numeric'),('macos_intel',root/'hosted/macos/numeric')]:
 values=np.load(folder/'operations.npz')['generated_weights']
 result[host]=dict(n=len(values),separate_exact=bool(values.tobytes()==plain.tobytes()),single_round_exact=bool(values.tobytes()==fused.tobytes()),
                  separate_differences=int(np.count_nonzero(values!=plain)),single_round_differences=int(np.count_nonzero(values!=fused)))
np.savez_compressed(root/'postprocess/uniform-scaling.npz',random_unit=r,separate=plain,single_round=fused)
(root/'postprocess/uniform-scaling.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
